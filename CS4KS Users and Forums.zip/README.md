### Instructions for this assignment can be found in the Guide.

Select **Tools->Guide->Play** to view the Guide for this project.
![playGuide](https://global.codio.com/platform/readme.resources/playGuide.png)
