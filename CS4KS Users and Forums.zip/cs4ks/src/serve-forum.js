const db = require('./database');
const templates = require('./templates');


/** @function homepage
 * Serves the home page 
 * @param {http.IncomingMessage} req - the request object 
 * @param {http.ServerResponse} res - the response object
 */
function serveForums(req, res) {
  // Get all forum TOPICS from database
  var topics = db.prepare("SELECT subject, forum_topics.id, first || ' ' || last AS creator,  (SELECT COUNT(id) FROM forum_posts WHERE forum_posts.forum_topic_id = forum_topics.id) as postCount, forum_topics.created_at AS date FROM forum_topics INNER JOIN users ON forum_topics.user_id = users.id ORDER BY forum_topics.created_at DESC;").all();
  
  // Generate the html snippets
  var postHtml = templates['topic-list.html']({post:topics});
  
  
  
   // Generate the page html
  var html = templates['forum.html']({post: postHtml,user: req.session && req.session.user});
  
  // Serve the HTML
  res.setHeader('Content-Type', "text/html");
  res.setHeader('Content-Length', html.length);
  res.end(html);
  
  
}


module.exports = serveForums;