const express = require('express');
const serveHomepage = require('./serve-homepage');
const serveStandards = require('./serve-standards');
const serveForums = require('./serve-forum');

const newPost = require('./endpoints/new-post');
const newTopic = require('./endpoints/new-topic');

const createPost = require('./endpoints/create-post');
const createTopic = require('./endpoints/create-topic');
const showPost = require('./endpoints/show-post');
const showTopic = require('./endpoints/show-topic');
const loadBody = require('./middleware/load-body');

const loadSession = require('./middleware/loadSession');
const authorsOnly = require('./middleware/authors-only');

const newUser = require('./endpoints/new-user.js');
const createUser = require('./endpoints/create-user');
const newSession = require('./endpoints/new-session');
const createSession = require('./endpoints/create-session');

const destroySession = require('./endpoints/destroy-session');



const path = require('path');




/** @module app 
 * The express application for our site
 */
var app = express();

app.use(loadSession);

//Routing to all the navigation pages
app.get('/', serveHomepage);
app.get('/standards', serveStandards);
app.get('/standards.html', serveStandards);
app.get('/forum',serveForums);


//Routing to all pages dealing with Topics
app.get('/forum/topics/new', newTopic);
app.post('/forum/topics', authorsOnly,loadBody, createTopic);
app.get('/forum/topic/:id', showTopic);

//Routing to all pages dealing with Posts
app.get('/forum/topics/:id/posts',showTopic);
app.get('/forum/topics/:id/posts/new', newPost);
app.post('/forum/topics/:id/posts', authorsOnly, loadBody, createPost);
app.get('/forum/topics/:id/posts/:id',showPost);

  
//Routing to all pages dealing with signing up/creating users
app.get('/signup', newUser);
app.post('/signup', loadBody, createUser);


//Routing to all pages dealing with signing in/creating sessions
app.get('/signin', newSession);
app.post('/signin', loadBody, createSession);
app.get("/signout", destroySession);


//Routing to all pages dealing with styling and javascript code in public directory 
app.use(express.static('public'));
 
//Exports the app
module.exports = app;