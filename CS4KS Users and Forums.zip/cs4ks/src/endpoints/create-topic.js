const sanitizeHTML = require('sanitize-html');
const db = require('../database');
const serveError = require('../serve-error');

/** @function createPost()
 * Creates a new post using the supplied form data
 */
function createTopic(req, res) {
  var topic = req.body.subject;
  var author = req.body.author;
  var date = new Date().valueOf();
    
  // Validate the input
  if(!topic || !author) return serveError(req, res, 422, "Empty subject or author encountered");
  
  
  // Publish the topic to the database
  //Userid should be the number associated with the user
  var info = db.prepare("INSERT INTO forum_topics (subject, user_id) VALUES (?, ?);").run(topic,req.session.user.id);
  
  // Determine if the write succeeded
  if(info.changes !== 1) return serveError(req, res, 500, "Unable to write to database");
  
  
  // If sucesfully, should redirect to the read page for the topic 
  res.writeHead(302, {"Location": `/forum/topic/${info.lastInsertRowid}`});
  
  res.end();
}

module.exports = createTopic;