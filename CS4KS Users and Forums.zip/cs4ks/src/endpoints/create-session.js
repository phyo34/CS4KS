const bcrypt = require('bcrypt');
const templates = require('../templates');
const db = require('../database');
const serveError = require('../serve-error');
const sessions = require('../sessions');

/** @function createSession
 * A helper method invoked when session creation is
 * successful.  The request should have an object
 * as its body parameter with username and password set.
 * @param {http.IncomingMessage} req - the request object 
 * @param {http.ServerResponse} res - the response object
 */
function createSession(req, res) {
    var email = req.body.email;
    var password = req.body.password;
  //Getting the user
    var user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
  //If user does not exist, display message
    if(!user) return failure(req, res, "Email/Password not found.  Please try again.");
  //compare the passwords
    bcrypt.compare(password, user.crypted_password , (err, result) => {
     //if it does not match, serve error page
    if(err) return serveError(req, res, 500, err);
      //if matches, serve sucess page
    if(result) success(req, res, user);
      //Else, tell them it was not found
    else return failure(req, res, "Email/Password not found. Please try again.");
  });
}
/** @function success
 * Helper function for creating the user session after 
 * a successful login attempt.
 * @param {http.IncomingMessage} req - the request object 
 * @param {http.ServerResponse} res - the response object
 * @param {object} user - the user who signed in
 */
function success(req, res, user) {
  var sid = sessions.create(user);
  res.setHeader("Set-Cookie", `SID=${sid}; Secure; HTTPOnly`);
  res.statusCode = 302;
  res.setHeader("Location", "/forum");
  res.end();

}

/** @function failure 
 * A helper function for reporting issues logging a 
 * user in.
 * @param {http.IncomingMessage} req - the request object 
 * @param {http.ServerResponse} res - the response object
 * @param {string} errorMessage - the error message for the user
 */
function failure(req, res, errorMessage) {
  if(!errorMessage) errorMessage = "There was an error processing your request.  Please try again."
  var form = templates["signin.html"]({
    errorMessage: errorMessage
  });
  var html = templates["layout.html"]({
    title: "Sign In",
    post: form,
    list: "",
    user: req.session && req.session.user

  });
  res.setHeader("Content-Type", "text/html");
  res.setHeader("Content-Length", html.length);
  res.end(html);
}
module.exports = createSession;