const templates = require('../templates');


module.exports = function(req, res) {
  //Generate form, include errrorMessage to display when error occurs
  var form = templates["signup.html"]({
    errorMessage: ""
  });
  //Generate the HTML passing in the form 
  var html = templates["forum.html"]({
    title: "Sign Up",
    post: form,
    list: ""
  });
  res.setHeader("Content-Type", "text/html");
  res.setHeader("Content-Length", html.length);
  res.end(html);
}