const bcrypt = require('bcrypt');
const templates = require('../templates');
const db = require('../database');
const serveError = require('../serve-error');
const sessions = require('../sessions');
const createSession = require('./create-session');

/** @function createUser
 * An endpoint for creating a new user.  The request
 * should have an object as its body parameter with 
 * username, password, and passwordConfirmation set.
 * @param {http.IncomingMessage} req - the request object 
 * @param {http.ServerResponse} res - the response object
 */
function createUser(req, res) {
  //  Create the user
  var first= req.body.first;
  var last = req.body.last;
  var org = req.body.org;
  var role = req.body.role;
  var email = req.body.email;
  var password = req.body.password;
  var passwordConfirmation = req.body.passwordConfirmation;
  
  //Handles cases in which user does not have an input in a specific field 
  if(!first)  return inputFailure(req, res, "You must enter a first name. Please try again.");
  if(!last)  return inputFailure(req, res, "You must enter a last name. Please try again.");
  if(!org)  return inputFailure(req, res, "You must enter your organization. Please try again.");
  if(!email)  return inputFailure(req, res, "You must enter an email. Please try again.");
  if(!password)  return inputFailure(req, res, "You must enter a password. Please try again.");
  
  
  //Compares passwords to see if they match
  if(password !== passwordConfirmation) return inputFailure(req, res, "Your password and password confirmation must match.");
 
  //Checks to see if the email is in the database already
  var existingUser = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
  if(existingUser) return failure(req, res, `The email "${email}" is already taken. Please Sign In if you have an account.`);
 //Hashes the password
  const passes = 10;
  bcrypt.hash(password, passes, (err, hash) => {
    if(err) return serveError(req, res, 500, err);
 //  Save user to the database
  var info = db.prepare("INSERT INTO users ( first, last, organization, role, email,  crypted_password) values (  ?,   ?,   ?,   ?,   ?,  ?);").run(first,last,org,role,email, hash);
  if(info.changes === 1) success(req, res,info.lastInsertRowid );
  else inputFailure(req, res, "An error occurred.  Please try again.");
  });
}

/** @function success 
 * A helper method invoked when user creation is successful.
 * @param {http.IncomingMessage} req - the request object 
 * @param {http.ServerResponse} res - the response object
 * @param {integer} userID - the id of the user in the database
 */
function success(req, res, userID) {
   // Retrieve the user 
  var user = db.prepare("SELECT * FROM users WHERE id = ?").get(userID);
  
  // Create session
  var sid = sessions.create(user);
  // Set session cookie
  res.setHeader("Set-Cookie", `SID=${sid}; Secure; HTTPOnly`);
  // Redirect to home page
  res.statusCode = 302;
  res.setHeader("Location", "/forum");
  res.end("Logged in");
}

/** @function failure 
 * A helper method invoked when user creation fails due to account already existing
 * @param {http.IncomingMessage} req - the request object 
 * @param {http.ServerResponse} res - the response object
 * @param {string} errorMessage - a message to display to the user
 */
function failure(req, res, errorMessage) {
  if(!errorMessage) errorMessage = "There was an error processing your request.  Please try again."
 
    // Redirect to singin page
  res.statusCode = 302;
  res.setHeader("Location", "/signin");
  res.end("Sign in");
  
  
}



/** @function failure 
 * A helper method invoked when user creation fails due to input failure
 * @param {http.IncomingMessage} req - the request object 
 * @param {http.ServerResponse} res - the response object
 * @param {string} errorMessage - a message to display to the user
 */
function inputFailure (req,res,errorMessage){
  if(!errorMessage) errorMessage = "There was an error processing your request.  Please try again."
  var form = templates["signup.html"]({
    errorMessage: errorMessage
  });
  var html = templates["layout.html"]({
    title: "Sign Up",
    post: form,
    list: "",
    user: req.session && req.session.user

  });
  res.setHeader("Content-Type", "text/html");
  res.setHeader("Content-Length", html.length);
  res.end(html);
  
}
module.exports = createUser;