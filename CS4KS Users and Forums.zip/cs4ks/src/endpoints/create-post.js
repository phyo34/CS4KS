const sanitizeHTML = require('sanitize-html');
const db = require('../database');
const serveError = require('../serve-error');
const topicId = require('./show-topic');

/** @function createPost()
 * Creates a new post using the supplied form data
 */
function createPost(req, res) {
  var topic = req.body.author;
  var body = req.body.body;
  var date = new Date().valueOf();
   const id = parseInt(req.params.id, 10);
  // Validate the input
  if(!topic || !body) return serveError(req, res, 422, "Empty title or content encountered");
  
  // Sanitize the content
  body = sanitizeHTML(body);
  
  // Publish the post to the database
  var info = db.prepare("INSERT INTO forum_posts (body, forum_topic_id, user_id) VALUES (?,?,?);").run(body,id,req.session.user.id);
 
  // Determine if the write succeeded
  if(info.changes !== 1) return serveError(req, res, 500, "Unable to write to database");
    
  // Redirect to the read page for the post
  res.writeHead(302, {"Location": `/forum/topics/${id}/posts/${info.lastInsertRowid}`});
  res.end();
}

module.exports = createPost;