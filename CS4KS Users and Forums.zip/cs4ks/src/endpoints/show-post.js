const templates = require('../templates');
const db = require('../database');

/** @function showPost 
 * Serves the specified post as a resonse.  The post id should be in req.params.id
 * @param {http.IncomingMessage} req - the request object 
 * @param {http.ServerResponse} res - the response object 
 */
function showPost(req, res) {
  // Determine the post ID
  const id = parseInt(req.params.id, 10);
  
  // Retreive the post from the database based on the post ID
  var post = db.prepare("SELECT subject, forum_topics.id AS topicId, body, first || ' ' || last AS author, forum_topics.created_at AS date FROM forum_posts INNER JOIN users ON forum_posts.user_id = users.id INNER JOIN forum_topics ON forum_posts.forum_topic_id = forum_topics.id WHERE forum_posts.id = ? ORDER BY forum_posts.created_at ASC;").get(id);
  
  
  post.date = new Date(post.date);
 
  // Generate the HTML
  var postHtml = templates['post.html'](post);
  var html = templates['forum.html']({post: postHtml, id:id,user: req.session && req.session.user});
  // Serve the HTML
  res.setHeader("Content-Type", "text/html");
  res.setHeader("Content-Length", html.length);
  res.end(html);
}

module.exports = showPost;