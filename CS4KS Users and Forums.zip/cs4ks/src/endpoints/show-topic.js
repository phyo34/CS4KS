const templates = require('../templates');
const db = require('../database');

/** @function showPost 
 * Serves the specified post as a resonse.  The post id should be in req.params.id
 * @param {http.IncomingMessage} req - the request object 
 * @param {http.ServerResponse} res - the response object 
 */
function showTopic(req, res) {
  // Determine the topic  ID
 const id = parseInt(req.params.id, 10);
 
 // Get all posts in the database with that topic id 
  var posts= db.prepare("SELECT forum_topics.id AS topicid, forum_posts.id,subject, body, first || ' ' || last AS author, forum_topics.created_at AS date FROM forum_posts INNER JOIN users ON forum_posts.user_id = users.id INNER JOIN forum_topics ON forum_posts.forum_topic_id = forum_topics.id WHERE forum_topic_id = ? ORDER BY forum_posts.created_at ASC;").all(id);
   
 var subject = db.prepare("SELECT subject FROM forum_topics  WHERE forum_topics.id = ?").get(id);
   
    // Generate the html snippets, passing in the TOPIC subject as well
  var listHtml = templates['post-list.html']({post: posts,subject:subject});
  

  
   // Generate the page html 
  var html = templates['postForum.html']({post: listHtml, subject: subject,id: id, user: req.session && req.session.user});
  
  
  // Serve the HTML
  res.setHeader('Content-Type', "text/html");
  res.setHeader('Content-Length', html.length);
  res.end(html);
}




module.exports = showTopic;
