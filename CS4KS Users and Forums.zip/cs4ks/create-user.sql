INSERT INTO users (
  first,
  last,
  organization,
  role,
  email,
  crypted_password
) values (
  ?, 
  ?, 
  ?, 
  ?, 
  ?, 
  ?
);