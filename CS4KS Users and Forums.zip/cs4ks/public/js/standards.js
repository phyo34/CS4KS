
//gets table 
var table = document.querySelector("table");


/*@function generateMobileTable
 * Generates the table when in mobile mode
 * */
function generateMobileTable(table) {
  
 for (var i = 1, row; row = table.rows[i]; i++) {

   for (var j = 0, col; col = row.cells[j]; j++) {

          if(col.id == "identifier" || col.id == "description" ){
            col.style.display = "inline";
          }
           else {
              col.style.display="none";
           }
                       

            col.appendChild(document.createElement("br"));

      
   }  
     var cell2 = row.insertCell();  
     //button Name
              name = "btn" + i;
   var button = document.createElement("input");
             // Set button attributes
              button.setAttribute('type', 'button');
              button.setAttribute('value', 'More');
              button.setAttribute('class', 'myButton');
              button.setAttribute('ID', name);
              button.setAttribute('onclick', 'buttonClick()');
              cell2.appendChild(button);
          
 }

  
}

/*@function buttonClick
 * The buttonClick function tells the page to display either more or less
 * depending on the value of the button.
 * */

function buttonClick(){
    btnClicked = event.target.id;
var table = document.querySelector("table");

    var el = document.getElementById(btnClicked);
  
   //Getting the rowId based on the closest row the button is in 
   index = el.closest('tr').rowIndex;
      //If button value is 'More'
    if (el.value == 'More') {
              for (var i = 1, row; row = table.rows[i]; i++) {
                if (i == index) {
                   for (var j = 1, col; col = row.cells[j]; j++) {
                       if(col.id == "summary" || col.id == "concept" || col.id == "subconcept" || col.id == "practices"){
                            col.style.display = "inline";
                          }
                   }
                      
                  }
              }
                //Change button value to less
                   el.value = 'Less';
       }
                
    else {
          for (var i = 1, row; row = table.rows[i]; i++) {
             if (i == index) {
               for (var j = 1, col; col = row.cells[j]; j++) {
                   if(col.id == "summary" || col.id == "concept" || col.id == "subconcept" || col.id == "practices"){
                        col.style.display = "none";
                      }
                 
                      
                  }
             }
              }
         //Change button value to 'More'
         el.value = 'More';


      }
  
}



//Loads the mobile table when size is less than 700 
if(screen.width < 700){
     generateMobileTable(table);

}

//Reloads page when window is resized for convenience 
window.onresize = function(event)
{
document.location.reload(true);
}

    
    
  



  

